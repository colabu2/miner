﻿using Renci.SshNet;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for AutoSsh.xaml
    /// </summary>
    public partial class AutoSsh : Window
    {
        public AutoSsh()
        {
            InitializeComponent();

            string result;

            /*using (var client = new SshClient("8.tcp.ngrok.io", 12655, "root", "Zjnt3Zh3ewwAHoaMQW7N"))
            {
                #region Example SshCommand CreateCommand BeginExecute IsCompleted EndExecute

                client.Connect();


                var cmd = client.CreateCommand("lscpu"); // Perform long running task

                var asynch = cmd.BeginExecute();

                while (!asynch.IsCompleted)
                {
                    //  Waiting for command to complete...
                    Thread.Sleep(2000);
                }
                result = cmd.EndExecute(asynch);
                client.Disconnect();

                #endregion
                txtBox.AppendText(result);

            }*/

        }

        class Client
        {
            private SshClient client;

            public SshClient GetClient()
            {
                return client;
            }

            public void SetClient(SshClient client)
            {
                this.client = client;
            }
        }


        private void connect_Click(object sender, RoutedEventArgs e)
        {
            string host= hostname.Text;
            string port1 = port.Text;
            string username1 = username.Text;
            string password = password_Copy.Text;

            string result;
            var client = new Client();
            client.SetClient(new SshClient(host, Convert.ToInt32(port1), username1, password));

            var getClient = client.GetClient();
            getClient.Connect();

            var cmd = getClient.CreateCommand("echo 'Connected';"); // Perform long running task

            var asynch = cmd.BeginExecute();

            while (!asynch.IsCompleted)
            {
                //  Waiting for command to complete...
                Thread.Sleep(500);
            }
            result = cmd.EndExecute(asynch);
            getClient.Disconnect();

            txtBox.AppendText(result);
        }

        private void run_Click(object sender, RoutedEventArgs e)
        {
            /*string result;
            string host = hostname.Text;
            string port1 = port.Text;
            string username1 = username.Text;
            string password = password_Copy.Text;
            string comand = command.Text;
            
            var client = new Client();
            client.SetClient(new SshClient(host, Convert.ToInt32(port1), username1, password));

            var getClient = client.GetClient();
            getClient.Connect();

            var cmd = getClient.CreateCommand(comand); // Perform long running task
            var asynch = cmd.BeginExecute();

            *//*while (!asynch.IsCompleted)
            {
                //  Waiting for command to complete...
                Thread.Sleep(100);
            }*//*
            result = cmd.EndExecute(asynch);
            getClient.Disconnect();

            txtBox.AppendText(result);*/
            /*runCommand();*/
            /*string host = hostname.Text;
            string port1 = port.Text;
            string username1 = username.Text;
            string password = password_Copy.Text;
            string comand = command.Text;
            using (var sshClient = new SshClient(host, Convert.ToInt32(port1), username1, password))
            {
                sshClient.Connect();
                var cmd = sshClient.CreateCommand(comand);
                var asyncResult = cmd.BeginExecute();
                var outputReader = new StreamReader(cmd.OutputStream);
                string output;
                while (!asyncResult.IsCompleted)
                {
                    output = outputReader.ReadToEnd();
                    if (output != null)
                    {
                        txtBox.AppendText(output + Environment.NewLine);
                    }                    
                }
                output = outputReader.ReadToEnd();
                txtBox.AppendText(output + Environment.NewLine);
            }*/
            string host = hostname.Text;
            string port1 = port.Text;
            string username1 = username.Text;
            string password = password_Copy.Text;
            string comand = command.Text;
            var connInfo = new PasswordConnectionInfo(host, Convert.ToInt32(port1), username1, password);
            var sshClient = new SshClient(connInfo);

            sshClient.Connect();
            var stream = sshClient.CreateShellStream("", 0, 0, 0, 0, 1000);

            // Send the command
            stream.WriteLine("echo 'sample command output'");

            // Read with a suitable timeout to avoid hanging
            string line;
            while ((line = stream.ReadLine(TimeSpan.FromSeconds(2))) != null)
            {
                Trace.WriteLine(line);
                /*txtBox.AppendText(line + Environment.NewLine);*/
                // if a termination pattern is known, check it here and break to exit immediately
            }
            // ...
            stream.Close();
            // ...
            sshClient.Disconnect();


        }

        private void runCommand()
        {
            string host = hostname.Text;
            string port1 = port.Text;
            string username1 = username.Text;
            string password = password_Copy.Text;
            string comand = command.Text;

            using (var client = new SshClient(host, Convert.ToInt32(port1), username1, password))
            {
                client.Connect();
                // If the command2 depend on an environment modified by command1,
                // execute them like this.
                // If not, use separate CreateCommand calls.
                var cmd = client.CreateCommand(comand);

                var result = cmd.BeginExecute();

                using (var reader = new StreamReader(
                                      cmd.OutputStream, Encoding.UTF8, true, 1024, true))
                {
                    while (!result.IsCompleted || !reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        if (line != null)
                        {
                            txtBox.AppendText(line + Environment.NewLine);
                        }
                    }
                }

                cmd.EndExecute(result);
            }
        }

    }

}
