﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MenuWindow.xaml
    /// </summary>
    public partial class MenuWindow : Window
    {
        public MenuWindow()
        {
            InitializeComponent();
        }

        private void goToBuatGmail(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private void goToLoginGmail(object sender, RoutedEventArgs e)
        {
            string curFile = @"D:\login.txt";
            bool exists = File.Exists(curFile);
            if (exists)
            {
                string[] lines = File.ReadAllLines(curFile);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i];
                    string[] subs = line.Split(',');
                    string email = $"{subs[0]}";
                    string pass = $"{subs[1]}";
                    LoginWindow loginWindow = new LoginWindow(email, pass, "https://colab.research.google.com/drive/1HFbdC4GnNXpNl8tBuiZPRIh4vw9fJB7t#scrollTo=sWyvGtRi5hAI");
                    loginWindow.Show();
                }
                /*for (int i = 40; i < 42; i++)
                {
                    LoginWindow loginWindow = new LoginWindow("colabarif"+i, "@Arif12345", "https://colab.research.google.com/?hl=id");
                    loginWindow.Show();
                }*/
            } else
            {
                MessageBox.Show("login.txt tidak ditemukan");
                Application.Current.Shutdown();
            }
        }

        private void autoSsh(object sender, RoutedEventArgs e)
        {
            AutoSsh ssh= new AutoSsh();
            ssh.Show();           
        }
    }
}
