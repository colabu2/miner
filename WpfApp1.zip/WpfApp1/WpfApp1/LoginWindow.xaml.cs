﻿using System;
using System.Threading.Tasks;
using System.Windows;
using Path = System.IO.Path;
using MihaZupan;
using System.Net.Http;
using Microsoft.Web.WebView2.Core;
using System.Diagnostics;
using System.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    /// 
    public partial class LoginWindow : Window
    {
        
        public LoginWindow(string gmail, string pass, string url)
        {
            InitializeComponent();
            load(gmail, pass, url);               
            /*testProxy();*/
            /*openBrowser();*/
        }

        public async void load(string gmail, string pass, string url)
        {
            Trace.WriteLine(gmail+" "+pass);
            wvLogin.CreationProperties = new Microsoft.Web.WebView2.Wpf.CoreWebView2CreationProperties();
            wvLogin.CreationProperties.UserDataFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{Guid.NewGuid()}");
            await wvLogin.EnsureCoreWebView2Async();
            wvLogin.CoreWebView2.Navigate("https://accounts.google.com/signin/v2/identifier?passive=true&continue=https%3A%2F%2Fcolab.research.google.com%2Fnotebooks%2Fintro.ipynb&ec=GAZAqQM&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
            wvLogin.CoreWebView2.Settings.UserAgent = "Mozilla/5.0 (Linux; Android 10; SM-J105H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Mobile Safari/537.36";
            await Task.Delay(7000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Gmail'); document.querySelector('#identifierId').value = '" + gmail + "'");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Next Pass'); document.querySelector('#identifierNext > div > button').click()");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Password'); document.querySelector('#password > div.aCsJod.oJeWuf > div > div.Xb9hP > input').value = '" + pass + "'");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Next Login'); document.querySelector('#passwordNext > div > button').click()");
            await Task.Delay(5000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("" +
                "console.log('Is Selection');" +
                " var url = document.URL; " +
                "if (url.indexOf('selection') >= 0) { document.querySelector('#view_container > div > div > div.pwWryf.bxPAYd > div > div.WEQkZc > div > form > span > section > div > div > div > ul > li:nth-child(3) > div').click(); window.setTimeout(function(){ document.querySelector('#knowledge-preregistered-email-response').value = 'arifdauhi11@gmail.com'; document.querySelector('#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button').click(); window.setTimeout(function(){ window.location = '" + url + "'; }, 3000); }, 3000); } else { console.log('Not'); window.location = '" + url+"';}");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Connect'); document.querySelector('#top-toolbar > colab-connect-button').shadowRoot.querySelector('#connect').click(); function closeCapt(){ var captcha = document.querySelector('body > colab-recaptcha-dialog'); if (captcha) { document.querySelector('body > colab-recaptcha-dialog').shadowRoot.querySelector('mwc-dialog > mwc-button').click()}; }");            
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Is Modal'); var url = document.URL; if (url.indexOf('research') >= 0) { var cancel = document.querySelector('#cancel'); if(cancel){ console.log(cancel); document.querySelector('#ok').click(); } }");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Run'); document.querySelector('#top-toolbar > colab-connect-button').shadowRoot.querySelector('#connect').click();");

            /*await wvLogin.CoreWebView2.ExecuteScriptAsync("" +
                "window.setTimeout(function(){ console.log('Colab'); var url = document.URL; if (url.indexOf('research') >= 0) {  window.setTimeout(function(){ var cancel = document.querySelector('#cancel'); if(cancel){ console.log(cancel); document.querySelector('#ok').click(); }, 3000); } else { alert('This url does not valid') }; }, 3000);");*/
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Run'); window.setTimeout(function(){ document.querySelector('#cell-sWyvGtRi5hAI > div.main-content > div.codecell-input-output > div.inputarea.horizontal.layout.code > div > div > colab-run-button').click(); }, 3000);");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Is Modal'); var cancel = document.querySelector('#cancel'); if(cancel){ console.log(cancel); window.setTimeout(function(){ document.querySelector('#ok').click(); }, 3000); } ");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Run'); window.setTimeout(function(){ document.querySelector('#cell-sWyvGtRi5hAI > div.main-content > div.codecell-input-output > div.inputarea.horizontal.layout.code > div > div > colab-run-button').click(); }, 3000);");
            await Task.Delay(3000);
            await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Is Modal'); var cancel = document.querySelector('#cancel'); if(cancel){ console.log(cancel); window.setTimeout(function(){ document.querySelector('#ok').click(); }, 3000); } ");           
            /*wvLogin.CoreWebView2.Navigate(url);*/
            /*
                        await Task.Delay(5000);
                        await wvLogin.CoreWebView2.ExecuteScriptAsync("console.log('Subscribe'); document.querySelector('#app > div.page-container > ytm-browse > ytm-c4-tabbed-header-renderer > div.c4-tabbed-header-channel.cbox > div > div > ytm-subscribe-button-renderer > div > c3-material-button > button').click();");
                        await Task.Delay(2000);*/
            /*this.Close();*/
            /*var captcha = document.querySelector('body > colab-recaptcha-dialog');
            if (captcha) { document.querySelector('body > colab-recaptcha-dialog').shadowRoot.querySelector('mwc-dialog > mwc-button').click(); }*/
        }

        public async void testProxy()
        {
            /*var proxy = new HttpToSocks5Proxy("94.130.171.189", 10029);
            var handler = new HttpClientHandler { Proxy = proxy };
            HttpClient httpClient = new HttpClient(handler, true);
*/
            CoreWebView2EnvironmentOptions options = new CoreWebView2EnvironmentOptions();
            Environment.SetEnvironmentVariable("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "--proxy-server=\"socks5://45.55.32.201:63556\"");
            CoreWebView2Environment env = await CoreWebView2Environment.CreateAsync(null, null, options);
            wvLogin.CreationProperties = new Microsoft.Web.WebView2.Wpf.CoreWebView2CreationProperties();
            wvLogin.CreationProperties.UserDataFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{Guid.NewGuid()}");
            await wvLogin.EnsureCoreWebView2Async(env);
            wvLogin.CoreWebView2.Navigate("https://whatismyipaddress.com/");
            await Task.Delay(10000);
            wvLogin.CoreWebView2.Navigate("https://google.com");


            /*
            var result = await httpClient.SendAsync(
                new HttpRequestMessage(HttpMethod.Get, "https://httpbin.org/ip"));
            MessageBox.Show("HTTPS GET: " + await result.Content.ReadAsStringAsync());
            Console.WriteLine("HTTPS GET: " + await result.Content.ReadAsStringAsync());*/
        }

        public async void openBrowser()
        {           
            wvLogin.CreationProperties = new Microsoft.Web.WebView2.Wpf.CoreWebView2CreationProperties();
            wvLogin.CreationProperties.UserDataFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{Guid.NewGuid()}");           
            await wvLogin.EnsureCoreWebView2Async();
            wvLogin.CoreWebView2.Navigate("https://youtube.com");
        }
    }
}