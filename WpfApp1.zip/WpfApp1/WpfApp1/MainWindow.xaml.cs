﻿using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
            string curFile = @"D:\Akun.txt";

            bool exists = File.Exists(curFile);
            if (exists)
            {
                string[] lines = File.ReadAllLines(curFile);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i];
                    string[] subs = line.Split(',');
                    string first = $"{subs[0]}";
                    string last = $"{subs[1]}";
                    string email = $"{subs[2]}";
                    string pass = $"{subs[3]}";
                    string phone = $"{subs[4]}";
                    
                    if (i == 0)
                    {
                        load(first, last, email, pass, phone);
                    }
                    else if (i == 1)
                    {
                        load1(first, last, email, pass, phone);
                    }
                    else if (i == 2)
                    {
                        load2(first, last, email, pass, phone);
                    }
                }
            }
            else
            {
                MessageBox.Show("Akun.txt tidak ditemukan");
                Application.Current.Shutdown();
            }
        }

        public async void load(string first, string last, string email, string pass, string phone)
        {
            wvMain.CreationProperties = new Microsoft.Web.WebView2.Wpf.CoreWebView2CreationProperties();
            wvMain.CreationProperties.UserDataFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{Guid.NewGuid()}");            
            await wvMain.EnsureCoreWebView2Async();
            wvMain.CoreWebView2.Navigate("https://accounts.google.com/signup/v2/webcreateaccount?continue=https%3A%2F%2Fwww.google.com%2F&hl=id&dsh=S-569721758%3A1643245699867171&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp");
            await Task.Delay(7000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Firstname'); document.querySelector('#firstName').value = '"+first+"'");
            await Task.Delay(3000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Lastname'); document.querySelector('#lastName').value = '" + last + "'");
            await Task.Delay(3000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Email'); document.querySelector('#username').value = '" + email + "'");
            await Task.Delay(3000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Password'); document.querySelector('#passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input').value = '" + pass + "'");
            await Task.Delay(3000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Confirm'); document.querySelector('#confirm-passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input').value = '" + pass + "'");
            await Task.Delay(3000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Click'); document.querySelector('#accountDetailsNext > div > button').click()");
            await Task.Delay(3000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Phone Number'); document.querySelector('#phoneNumberId').value = '" + phone + "'");
            await Task.Delay(3000);
            await wvMain.CoreWebView2.ExecuteScriptAsync("console.log('Click'); document.querySelector('#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button').click()");
        }

        public async void load1(string first, string last, string email, string pass, string phone)
        {
            wvMain1.CreationProperties = new Microsoft.Web.WebView2.Wpf.CoreWebView2CreationProperties();
            wvMain1.CreationProperties.UserDataFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{Guid.NewGuid()}");
            await wvMain1.EnsureCoreWebView2Async();
            wvMain1.CoreWebView2.Navigate("https://accounts.google.com/signup/v2/webcreateaccount?continue=https%3A%2F%2Fwww.google.com%2F&hl=id&dsh=S-569721758%3A1643245699867171&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp");
            await Task.Delay(7000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Firstname'); document.querySelector('#firstName').value = '" + first + "'");
            await Task.Delay(3000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Lastname'); document.querySelector('#lastName').value = '" + last + "'");
            await Task.Delay(3000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Email'); document.querySelector('#username').value = '" + email + "'");
            await Task.Delay(3000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Password'); document.querySelector('#passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input').value = '" + pass + "'");
            await Task.Delay(3000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Confirm'); document.querySelector('#confirm-passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input').value = '" + pass + "'");
            await Task.Delay(3000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Click'); document.querySelector('#accountDetailsNext > div > button').click()");
            await Task.Delay(3000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Phone Number'); document.querySelector('#phoneNumberId').value = '" + phone + "'");
            await Task.Delay(3000);
            await wvMain1.CoreWebView2.ExecuteScriptAsync("console.log('Click'); document.querySelector('#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button').click()");
        }

        public async void load2(string first, string last, string email, string pass, string phone)
        {
            wvMain2.CreationProperties = new Microsoft.Web.WebView2.Wpf.CoreWebView2CreationProperties();
            wvMain2.CreationProperties.UserDataFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{Guid.NewGuid()}");
            await wvMain2.EnsureCoreWebView2Async();
            wvMain2.CoreWebView2.Navigate("https://accounts.google.com/signup/v2/webcreateaccount?continue=https%3A%2F%2Fwww.google.com%2F&hl=id&dsh=S-569721758%3A1643245699867171&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp");
            await Task.Delay(7000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Firstname'); document.querySelector('#firstName').value = '" + first + "'");
            await Task.Delay(3000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Lastname'); document.querySelector('#lastName').value = '" + last + "'");
            await Task.Delay(3000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Email'); document.querySelector('#username').value = '" + email + "'");
            await Task.Delay(3000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Password'); document.querySelector('#passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input').value = '" + pass + "'");
            await Task.Delay(3000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Confirm'); document.querySelector('#confirm-passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input').value = '" + pass + "'");
            await Task.Delay(3000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Click'); document.querySelector('#accountDetailsNext > div > button').click()");
            await Task.Delay(3000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Phone Number'); document.querySelector('#phoneNumberId').value = '" + phone + "'");
            await Task.Delay(3000);
            await wvMain2.CoreWebView2.ExecuteScriptAsync("console.log('Click'); document.querySelector('#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button').click()");
        }

    }
}
